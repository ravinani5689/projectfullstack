package com.leave;

public class LeaveManagementApplication {
    public static void main(String[] args){
        System.out.println("Starter project");
    }
}
