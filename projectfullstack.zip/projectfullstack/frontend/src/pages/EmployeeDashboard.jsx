import { useEffect, useState } from "react";
import api from "../api/axios";
import LoadingSpinner from "../components/LoadingSpinner";
import StatusBadge from "../components/StatusBadge";

const EmployeeDashboard = () => {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchSummary = async () => {
      try {
        const { data } = await api.get("/employees/dashboard/summary");
        setSummary(data);
      } catch (err) {
        setError(err.response?.data?.message || "Failed to load dashboard");
      } finally {
        setLoading(false);
      }
    };
    fetchSummary();
  }, []);

  if (loading) return <LoadingSpinner />;
  if (error) return <div className="alert alert-error">{error}</div>;

  return (
    <div className="page">
      <h1>Employee Dashboard</h1>

      <div className="stat-grid">
        <div className="stat-card">
          <span className="stat-number">{summary.totalRequests}</span>
          <span className="stat-label">Total Requests</span>
        </div>
        <div className="stat-card stat-approved">
          <span className="stat-number">{summary.approved}</span>
          <span className="stat-label">Approved</span>
        </div>
        <div className="stat-card stat-pending">
          <span className="stat-number">{summary.pending}</span>
          <span className="stat-label">Pending</span>
        </div>
        <div className="stat-card stat-rejected">
          <span className="stat-number">{summary.rejected}</span>
          <span className="stat-label">Rejected</span>
        </div>
      </div>

      <h2>Recent Activity</h2>
      {summary.recentActivity.length === 0 ? (
        <p className="empty-state">No leave requests yet.</p>
      ) : (
        <table className="data-table">
          <thead>
            <tr>
              <th>Type</th>
              <th>Start</th>
              <th>End</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {summary.recentActivity.map((leave) => (
              <tr key={leave._id}>
                <td>{leave.leaveType}</td>
                <td>{new Date(leave.startDate).toLocaleDateString()}</td>
                <td>{new Date(leave.endDate).toLocaleDateString()}</td>
                <td>
                  <StatusBadge status={leave.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default EmployeeDashboard;
