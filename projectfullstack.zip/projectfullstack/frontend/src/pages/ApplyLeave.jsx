import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";

const LEAVE_TYPES = ["Sick", "Casual", "Annual", "Unpaid", "Maternity", "Paternity"];

const ApplyLeave = () => {
  const [form, setForm] = useState({ leaveType: "", startDate: "", endDate: "", reason: "" });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validate = () => {
    if (!form.leaveType || !form.startDate || !form.endDate || !form.reason.trim()) {
      return "All fields are required.";
    }
    if (new Date(form.endDate) < new Date(form.startDate)) {
      return "End date cannot be before start date.";
    }
    if (form.reason.trim().length < 5) {
      return "Please provide a more detailed reason (at least 5 characters).";
    }
    return "";
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    setSubmitting(true);
    try {
      await api.post("/leaves", form);
      setSuccess("Leave request submitted successfully.");
      setTimeout(() => navigate("/employee/leave-history"), 1200);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to submit leave request.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="page">
      <h1>Apply for Leave</h1>

      <form className="form-card" onSubmit={handleSubmit}>
        {error && <div className="alert alert-error">{error}</div>}
        {success && <div className="alert alert-success">{success}</div>}

        <label htmlFor="leaveType">Leave Type</label>
        <select id="leaveType" name="leaveType" value={form.leaveType} onChange={handleChange}>
          <option value="">Select type</option>
          {LEAVE_TYPES.map((type) => (
            <option key={type} value={type}>
              {type}
            </option>
          ))}
        </select>

        <label htmlFor="startDate">Start Date</label>
        <input
          id="startDate"
          type="date"
          name="startDate"
          value={form.startDate}
          onChange={handleChange}
        />

        <label htmlFor="endDate">End Date</label>
        <input id="endDate" type="date" name="endDate" value={form.endDate} onChange={handleChange} />

        <label htmlFor="reason">Reason</label>
        <textarea
          id="reason"
          name="reason"
          rows={4}
          value={form.reason}
          onChange={handleChange}
          placeholder="Briefly explain the reason for your leave"
        />

        <button type="submit" disabled={submitting}>
          {submitting ? "Submitting..." : "Submit Request"}
        </button>
      </form>
    </div>
  );
};

export default ApplyLeave;
