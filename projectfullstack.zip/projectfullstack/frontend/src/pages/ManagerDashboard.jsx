import { useEffect, useState } from "react";
import api from "../api/axios";
import LoadingSpinner from "../components/LoadingSpinner";
import StatusBadge from "../components/StatusBadge";

const ManagerDashboard = () => {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchSummary = async () => {
      try {
        const { data } = await api.get("/employees/dashboard/manager-summary");
        setSummary(data);
      } catch (err) {
        setError(err.response?.data?.message || "Failed to load dashboard");
      } finally {
        setLoading(false);
      }
    };
    fetchSummary();
  }, []);

  if (loading) return <LoadingSpinner />;
  if (error) return <div className="alert alert-error">{error}</div>;

  return (
    <div className="page">
      <h1>Manager Dashboard</h1>

      <div className="stat-grid">
        <div className="stat-card">
          <span className="stat-number">{summary.totalEmployees}</span>
          <span className="stat-label">Total Employees</span>
        </div>
        <div className="stat-card stat-pending">
          <span className="stat-number">{summary.pending}</span>
          <span className="stat-label">Pending Approvals</span>
        </div>
        <div className="stat-card stat-approved">
          <span className="stat-number">{summary.approved}</span>
          <span className="stat-label">Approved</span>
        </div>
        <div className="stat-card stat-rejected">
          <span className="stat-number">{summary.rejected}</span>
          <span className="stat-label">Rejected</span>
        </div>
      </div>

      <h2>Recent Activity</h2>
      {summary.recentActivity.length === 0 ? (
        <p className="empty-state">No leave activity yet.</p>
      ) : (
        <table className="data-table">
          <thead>
            <tr>
              <th>Employee</th>
              <th>Department</th>
              <th>Type</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {summary.recentActivity.map((leave) => (
              <tr key={leave._id}>
                <td>{leave.employee?.name || "—"}</td>
                <td>{leave.employee?.department || "—"}</td>
                <td>{leave.leaveType}</td>
                <td>
                  <StatusBadge status={leave.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default ManagerDashboard;
