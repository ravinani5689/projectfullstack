import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [formError, setFormError] = useState("");
  const { login, loading } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError("");

    // Basic client-side validation before hitting the API.
    if (!email || !password) {
      setFormError("Please enter both email and password.");
      return;
    }

    try {
      const user = await login(email, password);
      navigate(user.role === "manager" ? "/manager/dashboard" : "/employee/dashboard");
    } catch (err) {
      setFormError(err.message);
    }
  };

  return (
    <div className="auth-page">
      <form className="auth-card" onSubmit={handleSubmit}>
        <h1>Leave Management System</h1>
        <p className="subtitle">Sign in to continue</p>

        {formError && <div className="alert alert-error">{formError}</div>}

        <label htmlFor="email">Email</label>
        <input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@company.com"
          autoComplete="username"
        />

        <label htmlFor="password">Password</label>
        <input
          id="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="••••••••"
          autoComplete="current-password"
        />

        <button type="submit" disabled={loading}>
          {loading ? "Signing in..." : "Sign In"}
        </button>

        <p className="hint">
          Sample: employee@demo.com / manager@demo.com — password123 (see README)
        </p>
      </form>
    </div>
  );
};

export default Login;
