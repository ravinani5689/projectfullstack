import { Link } from "react-router-dom";

const NotFound = () => (
  <div className="not-found-page">
    <h1>404</h1>
    <p>The page you're looking for doesn't exist.</p>
    <Link to="/login">Back to Login</Link>
  </div>
);

export default NotFound;
