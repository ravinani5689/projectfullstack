import { useEffect, useState } from "react";
import api from "../api/axios";
import LoadingSpinner from "../components/LoadingSpinner";

const PendingApprovals = () => {
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [actioningId, setActioningId] = useState(null);
  const [commentDraft, setCommentDraft] = useState({});

  const fetchPending = async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/leaves/pending/all");
      setLeaves(data.leaves);
      setError("");
    } catch (err) {
      setError(err.response?.data?.message || "Failed to load pending approvals");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPending();
  }, []);

  const handleApprove = async (id) => {
    setActioningId(id);
    try {
      await api.put(`/leaves/${id}/approve`, { comments: commentDraft[id] || "" });
      fetchPending();
    } catch (err) {
      alert(err.response?.data?.message || "Failed to approve request");
    } finally {
      setActioningId(null);
    }
  };

  const handleReject = async (id) => {
    const comments = commentDraft[id];
    if (!comments || !comments.trim()) {
      alert("Please add a comment explaining the rejection.");
      return;
    }
    setActioningId(id);
    try {
      await api.put(`/leaves/${id}/reject`, { comments });
      fetchPending();
    } catch (err) {
      alert(err.response?.data?.message || "Failed to reject request");
    } finally {
      setActioningId(null);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <div className="alert alert-error">{error}</div>;

  return (
    <div className="page">
      <h1>Pending Approvals</h1>

      {leaves.length === 0 ? (
        <p className="empty-state">No pending leave requests. All caught up!</p>
      ) : (
        <div className="approval-list">
          {leaves.map((leave) => (
            <div key={leave._id} className="approval-card">
              <div className="approval-header">
                <strong>{leave.employee?.name}</strong>
                <span>{leave.employee?.department}</span>
              </div>
              <p>
                <strong>{leave.leaveType}</strong> &middot;{" "}
                {new Date(leave.startDate).toLocaleDateString()} –{" "}
                {new Date(leave.endDate).toLocaleDateString()}
              </p>
              <p className="reason">{leave.reason}</p>

              <textarea
                placeholder="Comments (required for rejection)"
                value={commentDraft[leave._id] || ""}
                onChange={(e) =>
                  setCommentDraft({ ...commentDraft, [leave._id]: e.target.value })
                }
                rows={2}
              />

              <div className="approval-actions">
                <button
                  className="btn-small btn-approve"
                  disabled={actioningId === leave._id}
                  onClick={() => handleApprove(leave._id)}
                >
                  Approve
                </button>
                <button
                  className="btn-small btn-danger"
                  disabled={actioningId === leave._id}
                  onClick={() => handleReject(leave._id)}
                >
                  Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default PendingApprovals;
