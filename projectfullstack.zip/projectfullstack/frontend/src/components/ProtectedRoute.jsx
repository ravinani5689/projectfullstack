import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

// Wraps a page component. Redirects to /login if not authenticated,
// or to their own dashboard if their role doesn't match what the route requires.
const ProtectedRoute = ({ children, allowedRole }) => {
  const { user } = useAuth();

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRole && user.role !== allowedRole) {
    const fallback = user.role === "manager" ? "/manager/dashboard" : "/employee/dashboard";
    return <Navigate to={fallback} replace />;
  }

  return children;
};

export default ProtectedRoute;
