import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const dashboardPath = user?.role === "manager" ? "/manager/dashboard" : "/employee/dashboard";

  return (
    <nav className="navbar">
      <Link to={dashboardPath} className="navbar-brand">
        Leave Management
      </Link>

      {user && (
        <div className="navbar-links">
          {user.role === "employee" && (
            <>
              <Link to="/employee/dashboard">Dashboard</Link>
              <Link to="/employee/apply-leave">Apply Leave</Link>
              <Link to="/employee/leave-history">Leave History</Link>
            </>
          )}
          {user.role === "manager" && (
            <>
              <Link to="/manager/dashboard">Dashboard</Link>
              <Link to="/manager/pending-approvals">Pending Approvals</Link>
            </>
          )}
          <span className="navbar-user">
            {user.name} ({user.role})
          </span>
          <button onClick={handleLogout} className="btn-logout">
            Logout
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
