const LoadingSpinner = () => (
  <div className="spinner-wrapper">
    <div className="spinner" />
    <p>Loading...</p>
  </div>
);

export default LoadingSpinner;
