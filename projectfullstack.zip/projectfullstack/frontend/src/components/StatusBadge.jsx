// Small reusable component: color-codes a leave status for quick scanning in tables.
const StatusBadge = ({ status }) => {
  const colorMap = {
    Pending: "#b58900",
    Approved: "#2e7d32",
    Rejected: "#c62828",
    Cancelled: "#666666",
  };

  return (
    <span
      className="status-badge"
      style={{
        backgroundColor: `${colorMap[status] || "#666"}20`,
        color: colorMap[status] || "#666",
        border: `1px solid ${colorMap[status] || "#666"}`,
      }}
    >
      {status}
    </span>
  );
};

export default StatusBadge;
