const mongoose = require("mongoose");

// Establishes a single connection to MongoDB using the URI from environment variables.
// Called once when the server starts up (see server.js).
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`MongoDB connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error connecting to MongoDB: ${error.message}`);
    process.exit(1); // stop the app if we can't reach the database
  }
};

module.exports = connectDB;
