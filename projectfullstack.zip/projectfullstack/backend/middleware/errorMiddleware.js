// Catches anything not already handled (e.g. thrown errors, malformed JSON body).
// Express recognizes this as an error handler because it takes 4 arguments.
const errorHandler = (err, req, res, next) => {
  console.error(err.stack);

  const statusCode = res.statusCode && res.statusCode !== 200 ? res.statusCode : 500;
  res.status(statusCode).json({
    message: err.message || "Internal Server Error",
    // Stack trace only in development to avoid leaking internals in production.
    stack: process.env.NODE_ENV === "production" ? undefined : err.stack,
  });
};

// Handles requests to routes that don't exist.
const notFound = (req, res, next) => {
  res.status(404).json({ message: `Route not found: ${req.originalUrl}` });
};

module.exports = { errorHandler, notFound };
