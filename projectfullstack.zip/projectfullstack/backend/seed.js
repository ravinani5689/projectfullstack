// Populates the database with demo accounts so a reviewer can log in immediately.
// Run with: npm run seed  (from the backend/ directory)
const dotenv = require("dotenv");
const connectDB = require("./config/db");
const Employee = require("./models/Employee");
const Leave = require("./models/Leave");

dotenv.config();

const seed = async () => {
  await connectDB();

  await Employee.deleteMany();
  await Leave.deleteMany();

  const manager = await Employee.create({
    name: "Morgan Reyes",
    email: "manager@demo.com",
    password: "password123", // hashed automatically by the pre-save hook
    department: "Engineering",
    role: "manager",
  });

  const employee = await Employee.create({
    name: "Alex Chen",
    email: "employee@demo.com",
    password: "password123",
    department: "Engineering",
    role: "employee",
    manager: manager._id,
  });

  await Leave.create([
    {
      employee: employee._id,
      leaveType: "Sick",
      startDate: "2026-06-10",
      endDate: "2026-06-11",
      reason: "Flu symptoms",
      status: "Approved",
      managerComments: "Get well soon",
      reviewedBy: manager._id,
    },
    {
      employee: employee._id,
      leaveType: "Annual",
      startDate: "2026-07-15",
      endDate: "2026-07-18",
      reason: "Family vacation",
      status: "Pending",
    },
  ]);

  console.log("Seed data created:");
  console.log("  Manager  -> manager@demo.com / password123");
  console.log("  Employee -> employee@demo.com / password123");
  process.exit(0);
};

seed().catch((err) => {
  console.error("Seeding failed:", err);
  process.exit(1);
});
