const express = require("express");
const router = express.Router();
const {
  applyLeave,
  getLeaves,
  getLeaveById,
  updateLeave,
  cancelLeave,
  getPendingLeaves,
  approveLeave,
  rejectLeave,
} = require("../controllers/leaveController");
const { protect, authorize } = require("../middleware/auth");

// Manager-only routes declared before "/:id" routes to avoid route-param collisions.
router.get("/pending/all", protect, authorize("manager"), getPendingLeaves);
router.put("/:id/approve", protect, authorize("manager"), approveLeave);
router.put("/:id/reject", protect, authorize("manager"), rejectLeave);

router.post("/", protect, authorize("employee"), applyLeave);
router.get("/", protect, getLeaves); // both roles, scoped inside controller
router.get("/:id", protect, getLeaveById);
router.put("/:id", protect, authorize("employee"), updateLeave);
router.delete("/:id", protect, authorize("employee"), cancelLeave);

module.exports = router;
