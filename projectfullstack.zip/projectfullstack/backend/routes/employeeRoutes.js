const express = require("express");
const router = express.Router();
const {
  getEmployees,
  getEmployeeById,
  getEmployeeDashboard,
  getManagerDashboard,
} = require("../controllers/employeeController");
const { protect, authorize } = require("../middleware/auth");

// Dashboard routes declared before "/:id" so Express doesn't treat "dashboard" as an id param.
router.get("/dashboard/summary", protect, authorize("employee"), getEmployeeDashboard);
router.get("/dashboard/manager-summary", protect, authorize("manager"), getManagerDashboard);

router.get("/", protect, authorize("manager"), getEmployees);
router.get("/:id", protect, getEmployeeById);

module.exports = router;
