const mongoose = require("mongoose");

const leaveSchema = new mongoose.Schema(
  {
    employee: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Employee",
      required: true,
      index: true, // frequently queried by employee -> speeds up "my leave history"
    },
    leaveType: {
      type: String,
      enum: ["Sick", "Casual", "Annual", "Unpaid", "Maternity", "Paternity"],
      required: [true, "Leave type is required"],
    },
    startDate: {
      type: Date,
      required: [true, "Start date is required"],
    },
    endDate: {
      type: Date,
      required: [true, "End date is required"],
    },
    reason: {
      type: String,
      required: [true, "Reason is required"],
      trim: true,
      maxlength: 500,
    },
    status: {
      type: String,
      enum: ["Pending", "Approved", "Rejected", "Cancelled"],
      default: "Pending",
      index: true, // frequently filtered by status (e.g. pending approvals)
    },
    managerComments: {
      type: String,
      trim: true,
      default: "",
    },
    reviewedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Employee",
      default: null,
    },
  },
  { timestamps: true }
);

// Validate that endDate is not before startDate.
leaveSchema.pre("validate", function (next) {
  if (this.startDate && this.endDate && this.endDate < this.startDate) {
    return next(new Error("endDate cannot be before startDate"));
  }
  next();
});

// Compound index: most common query pattern is "this employee's leaves sorted by status"
leaveSchema.index({ employee: 1, status: 1 });

module.exports = mongoose.model("Leave", leaveSchema);
