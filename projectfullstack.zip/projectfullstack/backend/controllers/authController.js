const jwt = require("jsonwebtoken");
const Employee = require("../models/Employee");

// Helper to sign a JWT for a given user id.
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d",
  });
};

// @route   POST /api/auth/login
// @access  Public
const login = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required" });
  }

  try {
    // Password field has select:false in the schema, so we explicitly include it here.
    const user = await Employee.findOne({ email: email.toLowerCase() }).select("+password");

    if (!user || !(await user.matchPassword(password))) {
      // Deliberately vague message so we don't reveal whether the email exists.
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const token = generateToken(user._id);

    res.status(200).json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        department: user.department,
      },
    });
  } catch (error) {
    res.status(500).json({ message: "Server error during login", error: error.message });
  }
};

// @route   POST /api/auth/logout
// @access  Private
// Note: since we use stateless JWTs, "logout" is handled client-side by discarding
// the token. This endpoint exists for API completeness and to support future
// token-blacklisting if needed.
const logout = async (req, res) => {
  res.status(200).json({ message: "Logged out successfully" });
};

// @route   GET /api/auth/me
// @access  Private
const getMe = async (req, res) => {
  res.status(200).json({ user: req.user });
};

module.exports = { login, logout, getMe };
