const Leave = require("../models/Leave");

// @route   POST /api/leaves
// @access  Private (employee)
const applyLeave = async (req, res) => {
  try {
    const { leaveType, startDate, endDate, reason } = req.body;

    if (!leaveType || !startDate || !endDate || !reason) {
      return res.status(400).json({ message: "leaveType, startDate, endDate and reason are required" });
    }

    const leave = await Leave.create({
      employee: req.user._id,
      leaveType,
      startDate,
      endDate,
      reason,
    });

    res.status(201).json({ message: "Leave request submitted", leave });
  } catch (error) {
    // Mongoose validation errors (e.g. bad dates) land here with a 400, not a 500.
    if (error.name === "ValidationError") {
      return res.status(400).json({ message: error.message });
    }
    res.status(500).json({ message: "Failed to submit leave request", error: error.message });
  }
};

// @route   GET /api/leaves
// @access  Private (employee: own leaves only; manager: all leaves)
// Supports ?status=Pending&leaveType=Sick&search=text for filtering.
const getLeaves = async (req, res) => {
  try {
    const { status, leaveType, search } = req.query;
    const query = {};

    // Employees only ever see their own records; managers can see everyone's.
    if (req.user.role === "employee") {
      query.employee = req.user._id;
    }

    if (status) query.status = status;
    if (leaveType) query.leaveType = leaveType;
    if (search) query.reason = { $regex: search, $options: "i" };

    const leaves = await Leave.find(query)
      .populate("employee", "name email department")
      .sort({ createdAt: -1 });

    res.status(200).json({ count: leaves.length, leaves });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch leaves", error: error.message });
  }
};

// @route   GET /api/leaves/:id
// @access  Private
const getLeaveById = async (req, res) => {
  try {
    const leave = await Leave.findById(req.params.id).populate("employee", "name email department");
    if (!leave) {
      return res.status(404).json({ message: "Leave request not found" });
    }

    // An employee may only view their own leave request.
    if (req.user.role === "employee" && leave.employee._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to view this leave request" });
    }

    res.status(200).json({ leave });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch leave request", error: error.message });
  }
};

// @route   PUT /api/leaves/:id
// @access  Private (employee, only own AND only while Pending)
const updateLeave = async (req, res) => {
  try {
    const leave = await Leave.findById(req.params.id);
    if (!leave) {
      return res.status(404).json({ message: "Leave request not found" });
    }
    if (leave.employee.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to edit this leave request" });
    }
    if (leave.status !== "Pending") {
      return res.status(400).json({ message: `Cannot edit a leave request that is already ${leave.status}` });
    }

    const { leaveType, startDate, endDate, reason } = req.body;
    if (leaveType) leave.leaveType = leaveType;
    if (startDate) leave.startDate = startDate;
    if (endDate) leave.endDate = endDate;
    if (reason) leave.reason = reason;

    await leave.save(); // triggers schema validation (e.g. endDate >= startDate)
    res.status(200).json({ message: "Leave request updated", leave });
  } catch (error) {
    if (error.name === "ValidationError") {
      return res.status(400).json({ message: error.message });
    }
    res.status(500).json({ message: "Failed to update leave request", error: error.message });
  }
};

// @route   DELETE /api/leaves/:id
// @access  Private (employee, only own AND only while Pending -> cancels the request)
const cancelLeave = async (req, res) => {
  try {
    const leave = await Leave.findById(req.params.id);
    if (!leave) {
      return res.status(404).json({ message: "Leave request not found" });
    }
    if (leave.employee.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to cancel this leave request" });
    }
    if (leave.status !== "Pending") {
      return res.status(400).json({ message: `Cannot cancel a leave request that is already ${leave.status}` });
    }

    leave.status = "Cancelled";
    await leave.save();

    res.status(200).json({ message: "Leave request cancelled", leave });
  } catch (error) {
    res.status(500).json({ message: "Failed to cancel leave request", error: error.message });
  }
};

// @route   GET /api/leaves/pending/all
// @access  Private (manager)
const getPendingLeaves = async (req, res) => {
  try {
    const leaves = await Leave.find({ status: "Pending" })
      .populate("employee", "name email department")
      .sort({ createdAt: 1 }); // oldest pending first

    res.status(200).json({ count: leaves.length, leaves });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch pending leaves", error: error.message });
  }
};

// @route   PUT /api/leaves/:id/approve
// @access  Private (manager)
const approveLeave = async (req, res) => {
  try {
    const leave = await Leave.findById(req.params.id);
    if (!leave) {
      return res.status(404).json({ message: "Leave request not found" });
    }
    if (leave.status !== "Pending") {
      return res.status(400).json({ message: `Leave request is already ${leave.status}` });
    }

    leave.status = "Approved";
    leave.managerComments = req.body.comments || "";
    leave.reviewedBy = req.user._id;
    await leave.save();

    res.status(200).json({ message: "Leave request approved", leave });
  } catch (error) {
    res.status(500).json({ message: "Failed to approve leave request", error: error.message });
  }
};

// @route   PUT /api/leaves/:id/reject
// @access  Private (manager)
const rejectLeave = async (req, res) => {
  try {
    const { comments } = req.body;
    if (!comments) {
      return res.status(400).json({ message: "Comments are required when rejecting a leave request" });
    }

    const leave = await Leave.findById(req.params.id);
    if (!leave) {
      return res.status(404).json({ message: "Leave request not found" });
    }
    if (leave.status !== "Pending") {
      return res.status(400).json({ message: `Leave request is already ${leave.status}` });
    }

    leave.status = "Rejected";
    leave.managerComments = comments;
    leave.reviewedBy = req.user._id;
    await leave.save();

    res.status(200).json({ message: "Leave request rejected", leave });
  } catch (error) {
    res.status(500).json({ message: "Failed to reject leave request", error: error.message });
  }
};

module.exports = {
  applyLeave,
  getLeaves,
  getLeaveById,
  updateLeave,
  cancelLeave,
  getPendingLeaves,
  approveLeave,
  rejectLeave,
};
