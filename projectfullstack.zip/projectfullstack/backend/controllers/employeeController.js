const Employee = require("../models/Employee");
const Leave = require("../models/Leave");

// @route   GET /api/employees
// @access  Private (manager only)
// Supports optional search (?search=name-or-email) and department filter (?department=X)
const getEmployees = async (req, res) => {
  try {
    const { search, department } = req.query;
    const query = { role: "employee" };

    if (department) query.department = department;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
      ];
    }

    const employees = await Employee.find(query).select("-password");
    res.status(200).json({ count: employees.length, employees });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch employees", error: error.message });
  }
};

// @route   GET /api/employees/:id
// @access  Private
const getEmployeeById = async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id).select("-password");
    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }
    res.status(200).json({ employee });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch employee", error: error.message });
  }
};

// @route   GET /api/employees/dashboard/summary
// @access  Private (employee)
// Returns counts used by the employee dashboard widgets.
const getEmployeeDashboard = async (req, res) => {
  try {
    const employeeId = req.user._id;

    const [total, approved, pending, rejected, recent] = await Promise.all([
      Leave.countDocuments({ employee: employeeId }),
      Leave.countDocuments({ employee: employeeId, status: "Approved" }),
      Leave.countDocuments({ employee: employeeId, status: "Pending" }),
      Leave.countDocuments({ employee: employeeId, status: "Rejected" }),
      Leave.find({ employee: employeeId }).sort({ createdAt: -1 }).limit(5),
    ]);

    res.status(200).json({
      totalRequests: total,
      approved,
      pending,
      rejected,
      recentActivity: recent,
    });
  } catch (error) {
    res.status(500).json({ message: "Failed to load dashboard", error: error.message });
  }
};

// @route   GET /api/employees/dashboard/manager-summary
// @access  Private (manager)
const getManagerDashboard = async (req, res) => {
  try {
    const [totalEmployees, pending, approved, rejected, recent] = await Promise.all([
      Employee.countDocuments({ role: "employee" }),
      Leave.countDocuments({ status: "Pending" }),
      Leave.countDocuments({ status: "Approved" }),
      Leave.countDocuments({ status: "Rejected" }),
      Leave.find().sort({ updatedAt: -1 }).limit(5).populate("employee", "name department"),
    ]);

    res.status(200).json({
      totalEmployees,
      pending,
      approved,
      rejected,
      recentActivity: recent,
    });
  } catch (error) {
    res.status(500).json({ message: "Failed to load dashboard", error: error.message });
  }
};

module.exports = { getEmployees, getEmployeeById, getEmployeeDashboard, getManagerDashboard };
