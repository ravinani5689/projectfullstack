# Employee Leave Management System

A full-stack MVP that lets employees submit and track leave requests, and lets managers
review, approve, or reject them — replacing a manual email/spreadsheet process.

## Project Overview

This system has two roles:
- **Employee**: apply for leave, view leave history, edit/cancel pending requests, search & filter.
- **Manager**: view pending requests, approve/reject with comments, view team activity.

## Features

- JWT-based authentication with role-based access control (employee / manager)
- Protected routes on both frontend and backend
- Leave CRUD (create, read, update while pending, cancel while pending)
- Manager approval workflow with mandatory comments on rejection
- Dashboards with live counts (total / approved / pending / rejected)
- Search and filter on leave history (by status, type, keyword)
- Centralized error handling and consistent HTTP status codes
- Input validation on both client and server

## Technology Stack

| Layer      | Technology                                  |
|------------|----------------------------------------------|
| Frontend   | React (Vite), React Router, Axios            |
| Backend    | Node.js, Express                              |
| Database   | MongoDB with Mongoose ODM                     |
| Auth       | JSON Web Tokens (JWT), bcrypt password hashing|

**Why this stack:** MongoDB's document model fits leave records well since each record is
self-contained (no complex joins needed for the MVP), and Mongoose gives schema-level
validation. Express keeps the API layer minimal and easy to reason about. React + Vite
gives fast local dev without heavyweight tooling.

## Folder Structure

```
projectfullstack/
├── backend/
│   ├── config/          # DB connection
│   ├── controllers/     # route handler logic
│   ├── middleware/      # auth (JWT + RBAC), error handling
│   ├── models/          # Mongoose schemas (Employee, Leave)
│   ├── routes/          # Express route definitions
│   ├── seed.js          # demo data seeder
│   ├── server.js        # app entry point
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── api/         # axios instance with auth interceptor
│   │   ├── components/  # Navbar, Layout, ProtectedRoute, StatusBadge, LoadingSpinner
│   │   ├── context/      # AuthContext (global auth state)
│   │   ├── pages/        # Login, Dashboards, ApplyLeave, LeaveHistory, PendingApprovals, 404
│   │   ├── App.jsx
│   │   └── main.jsx
│   └── .env.example
├── postman/
│   └── Leave_Management_API.postman_collection.json
├── .gitignore
└── README.md
```

## Database Schema

**Employee**
| Field       | Type     | Notes                                  |
|-------------|----------|-----------------------------------------|
| name        | String   | required                                |
| email       | String   | required, unique (indexed for login)    |
| password    | String   | required, hashed with bcrypt, `select: false` by default |
| department  | String   | required                                |
| role        | String   | enum: `employee`, `manager`             |
| manager     | ObjectId | ref → Employee, optional                |
| createdAt / updatedAt | Date | auto-managed by timestamps       |

**Leave**
| Field           | Type     | Notes                                       |
|-----------------|----------|-----------------------------------------------|
| employee        | ObjectId | ref → Employee, required, indexed             |
| leaveType       | String   | enum: Sick, Casual, Annual, Unpaid, Maternity, Paternity |
| startDate/endDate | Date   | required; validated so endDate ≥ startDate     |
| reason          | String   | required, max 500 chars                        |
| status          | String   | enum: Pending, Approved, Rejected, Cancelled; indexed |
| managerComments | String   | set on approve/reject                            |
| reviewedBy      | ObjectId | ref → Employee (the manager who reviewed it)     |

**Relationships:** One employee → many leave requests (1:N). One manager may optionally
be linked to employees via the `manager` field (self-referencing relationship on Employee).

**Indexing strategy:** `email` is unique-indexed for fast login lookups. `Leave.employee`
and `Leave.status` are indexed individually and as a compound index, since the two most
common queries are "this employee's leaves" and "all pending leaves" — both hot paths for
the dashboards.

**Normalization:** Employee and Leave are kept as separate collections rather than
embedding leave records inside the employee document, since leave requests grow
unbounded over time and are queried independently (e.g., "all pending leaves across
every employee" for managers).

## Installation Steps

### Prerequisites
- Node.js 18+
- MongoDB running locally, or a free MongoDB Atlas cluster

### Database Setup
1. Install MongoDB locally, or create a free cluster at mongodb.com/atlas
2. Note your connection string, e.g. `mongodb://localhost:27017/leave-management`

### Backend Setup
```bash
cd backend
npm install
cp .env.example .env
# edit .env: set MONGO_URI and a strong JWT_SECRET
npm run seed     # creates demo manager + employee accounts with sample leave data
npm run dev      # starts the API on http://localhost:5000
```

### Frontend Setup
```bash
cd frontend
npm install
cp .env.example .env
# edit .env if your backend runs on a different port
npm run dev      # starts the app on http://localhost:5173
```

### Running the Application
1. Start MongoDB (if running locally: `mongod`)
2. Start the backend (`npm run dev` inside `backend/`)
3. Start the frontend (`npm run dev` inside `frontend/`)
4. Visit `http://localhost:5173` and log in with a sample account below

## Environment Variables

**backend/.env**
| Variable        | Description                          |
|-----------------|----------------------------------------|
| PORT            | Port the API listens on (default 5000) |
| MONGO_URI       | MongoDB connection string              |
| JWT_SECRET      | Secret used to sign JWTs               |
| JWT_EXPIRES_IN  | Token lifetime, e.g. `7d`              |
| NODE_ENV        | `development` or `production`          |

**frontend/.env**
| Variable            | Description                    |
|---------------------|----------------------------------|
| VITE_API_BASE_URL   | Base URL of the backend API      |

## Sample Login Credentials

After running `npm run seed` in the backend:

| Role     | Email              | Password    |
|----------|--------------------|--------------|
| Manager  | manager@demo.com   | password123 |
| Employee | employee@demo.com  | password123 |

## API Documentation

Full endpoint documentation is provided as a Postman collection:
`postman/Leave_Management_API.postman_collection.json` — import it into Postman and set
the `token` collection variable after logging in.

### Endpoint Summary

| Method | Endpoint                        | Access          | Description                     |
|--------|----------------------------------|-----------------|-----------------------------------|
| POST   | /api/auth/login                 | Public          | Login, returns JWT + user         |
| POST   | /api/auth/logout                | Private          | Stateless logout (client discards token) |
| GET    | /api/auth/me                    | Private          | Get current logged-in user        |
| GET    | /api/employees                  | Manager          | List employees (search/filter)    |
| GET    | /api/employees/:id               | Private          | Get one employee                  |
| GET    | /api/employees/dashboard/summary | Employee         | Employee dashboard counts         |
| GET    | /api/employees/dashboard/manager-summary | Manager  | Manager dashboard counts          |
| POST   | /api/leaves                     | Employee         | Apply for leave                   |
| GET    | /api/leaves                     | Both (scoped)    | List leaves (filter by status/type/search) |
| GET    | /api/leaves/:id                  | Both (scoped)    | Get one leave request             |
| PUT    | /api/leaves/:id                  | Employee (owner) | Edit a **pending** leave request  |
| DELETE | /api/leaves/:id                  | Employee (owner) | Cancel a **pending** leave request|
| GET    | /api/leaves/pending/all           | Manager          | List all pending requests         |
| PUT    | /api/leaves/:id/approve           | Manager          | Approve a request                 |
| PUT    | /api/leaves/:id/reject            | Manager          | Reject a request (comments required) |

All private routes require header: `Authorization: Bearer <token>`

### Sample response — `POST /api/auth/login`
```json
{
  "token": "eyJhbGciOiJI...",
  "user": {
    "id": "64f...",
    "name": "Alex Chen",
    "email": "employee@demo.com",
    "role": "employee",
    "department": "Engineering"
  }
}
```

### Error response shape
```json
{ "message": "Invalid email or password" }
```

### Status codes used
`200` success · `201` created · `400` validation error · `401` unauthenticated ·
`403` forbidden (wrong role / not owner) · `404` not found · `500` server error

## Assumptions

- One manager role reviews all leave requests (no per-team manager scoping in this MVP)
- Leave balance/entitlement tracking is out of scope for the MVP
- "Logout" is handled client-side by discarding the JWT (no server-side token blacklist)

## Known Limitations

- No JWT refresh token — user must re-login after the token expires
- No automated tests included
- No pagination yet on leave/employee lists (fine at demo scale, would matter at production scale)
- No email notifications on approval/rejection

## Future Enhancements

- Refresh tokens + shorter-lived access tokens
- Leave balance calculation per employee per leave type
- Pagination and infinite scroll for large datasets
- Email notifications (e.g., via SendGrid) on status changes
- Audit log of all approval/rejection actions
- Docker Compose setup for one-command local dev
- CI pipeline (GitHub Actions) running lint + tests on PRs
- Unit and integration tests (Jest + Supertest for backend, React Testing Library for frontend)

## Challenges Encountered

- Balancing MVP scope against the full feature wishlist within the assessment timeline —
  prioritized the auth/RBAC/CRUD/approval core since that's what the grading rubric
  weights most heavily (backend + DB + API design = 50 of 100 marks).

## Potential Improvements With More Time

- Add automated tests to lock in correctness of the approval workflow
- Add optimistic UI updates on approve/reject instead of full refetch
- Add per-department manager scoping instead of a single flat manager role
